#include <vector>

using namespace std;

class spline{

public:
    int nodes;

    double h[10000];
    double z[10000];

    double* X;
    double* Y;

    spline(int n);

    void set_points( double x[], double y[]);

    double operator() (double z) const;
};