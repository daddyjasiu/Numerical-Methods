//Jan Skwarczek

#include <iostream>
#include "source.h"

using namespace std;

spline::spline(int n){
    nodes = n;
}

void spline::set_points(double *x, double *y) {

    X = x;
    Y = y;

    double u[10000];
    double v[10000];
    double b[10000];

    for (int i = 0; i < nodes-1; ++i){
        h[i] = (x[i+1] - x[i]);
        b[i] = (6*(y[i+1] - y[i]) / h[i]);
    }

    u[1] = (2*(h[0] + h[1]));
    v[1] = (b[1] - b[0]);

    for (int i = 2; i < nodes-1; ++i) {
        u[i] = (2*(h[i-1] + h[i]) - (h[i-1]*h[i-1]) / u[i-1]);
        v[i] = (b[i] - b[i-1] - h[i-1]*v[i-1] / u[i-1]);

    }

    z[nodes-1] = 0;

    for (int i = nodes-2; i > 0; --i) {
        z[i] = ((v[i] -h[i] * z[i + 1]) / u[i]);
    }

    z[0] = 0;

}

double spline::operator()(double var) const {

    int i = 0;

    for (int j = nodes - 1; j >= 0; --j) {
        if((var - X[j]) >= 0) {
            i = j;
            break;
        }
    }

    double A = (z[i+1] - z[i]) / (6 * h[i]);
    double B = z[i] / 2;
    double C = -(h[i]/6) * (z[i+1] + 2 * z[i]) + (Y[i+1] - Y[i]) / h[i];

    double result = Y[i] + (var - X[i]) * (C + (var - X[i]) * (B + (var - X[i]) * A));

    return result;

}